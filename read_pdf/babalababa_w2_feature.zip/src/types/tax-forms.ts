import { W2Form } from './w2';

export interface Form1040 {
  taxYear: number;
  filingStatus: 'single' | 'married_filing_jointly' | 'married_filing_separately' | 'head_of_household' | 'qualifying_surviving_spouse';
  
  taxpayerInfo: {
    ssn: string;
    firstName: string;
    lastName: string;
    itin?: string;
  };
  
  spouseInfo?: {
    ssn: string;
    firstName: string;
    lastName: string;
    itin?: string;
  };
  
  address: {
    homeAddress: string;
    apartmentNumber?: string;
    city: string;
    state: string;
    zipCode: string;
    foreignCountry?: string;
    foreignProvince?: string;
    foreignPostalCode?: string;
  };
  
  income: {
    wages: number;
    taxableInterest: number;
    ordinaryDividends: number;
    iraDistributions: number;
    pensionsAndAnnuities: number;
    socialSecurityBenefits: number;
    capitalGainOrLoss: number;
    otherIncome: number;
    totalIncome: number;
  };
  
  adjustments: {
    educatorExpenses: number;
    hsaDeduction: number;
    businessIncomeLoss: number;
    selfEmploymentTax: number;
    selfEmploymentHealthInsurance: number;
    penaltyOnEarlyWithdrawal: number;
    alaskaPermanentFundDividend: number;
    otherAdjustments: number;
    totalAdjustments: number;
  };
  
  deductions: {
    standardDeduction: number;
    qualifiedBusinessIncomeDeduction: number;
    sumOfDeductions: number;
    taxableIncome: number;
  };
  
  taxAndCredits: {
    computedTax: number;
    alternativeMinimumTax: number;
    excessAdvancePremiumTaxCreditRepayment: number;
    totalTax: number;
    childTaxCredit: number;
    recoveryRebateCredit: number;
    otherCredits: number;
    totalCredits: number;
  };
  
  payments: {
    federalTaxWithheld: number;
    estimatedTaxPayments: number;
    refundableCredits: number;
    otherPayments: number;
    totalPayments: number;
  };
  
  refund: {
    overpayment: number;
    amountRefunded: number;
    appliedToNextYear: number;
  };
  
  amountYouOwe: number;
  
  sourceW2s: W2Form[];
}

export interface Form941 {
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  taxYear: number;
  
  employerInfo: {
    ein: string;
    name: string;
    tradeName?: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
  };
  
  taxLiability: {
    line2: number;
    line5a: number;
    line5b: number;
    line5c: number;
    line5d: number;
    line5e: number;
    line5f: number;
    line5_total: number;
    line6: number;
    line7: number;
    line7a: number;
    line7b: number;
    line7c: number;
    line8: number;
    line10: number;
    line11: number;
    line12a: number;
    line12b: number;
    line13: number;
  };
  
  deposits: {
    totalTaxDeposited: number;
    overpayment: number;
    overpaymentApplied: number;
    overpaymentRefunded: number;
  };
  
  monthlyLiability: MonthlyLiability[];
  
  sourceW2s: W2Form[];
}

export interface MonthlyLiability {
  month: string;
  socialSecurityWages: number;
  socialSecurityTax: number;
  medicareWages: number;
  medicareTax: number;
  withholdingTax: number;
}
