import { NextRequest, NextResponse } from 'next/server';
import { taxFormMapperService } from '@/services/tax-form-mapper';
import { W2Form } from '@/types/w2';
import { Form941 } from '@/types/tax-forms';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { w2Forms, taxYear, quarter } = body as {
      w2Forms: W2Form[];
      taxYear: number;
      quarter: Form941['quarter'];
    };

    if (!w2Forms || w2Forms.length === 0) {
      return NextResponse.json({ error: 'No W2 forms provided' }, { status: 400 });
    }

    if (!taxYear || !quarter) {
      return NextResponse.json({ error: 'Tax year and quarter are required' }, { status: 400 });
    }

    const form941 = taxFormMapperService.mapW2ToForm941(w2Forms, taxYear, quarter);

    return NextResponse.json(form941);
  } catch (error) {
    console.error('Error generating Form 941:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to generate Form 941' },
      { status: 500 }
    );
  }
}
