'use client';

import { useState } from 'react';
import W2_Uploader from '@/components/W2_Uploader';
import W2_DataDisplay from '@/components/W2_DataDisplay';
import W2_TaxFormGenerator from '@/components/W2_TaxFormGenerator';

export default function Home() {
  const [parsedW2Data, setParsedW2Data] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-blue-600 mb-4">
            W2 Tax Form Filler
          </h1>
          <p className="text-xl text-gray-600">
            Upload your W2 form and automatically generate tax documents
          </p>
        </header>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <W2_Uploader
              onDataParsed={setParsedW2Data}
              isProcessing={isProcessing}
              setIsProcessing={setIsProcessing}
            />
            
            {parsedW2Data && (
              <W2_DataDisplay data={parsedW2Data} />
            )}
          </div>

          <div className="space-y-6">
            {parsedW2Data && parsedW2Data.w2Forms && parsedW2Data.w2Forms.length > 0 ? (
              <W2_TaxFormGenerator w2Forms={parsedW2Data.w2Forms} />
            ) : (
              <div className="card">
                <div className="text-center text-gray-500">
                  <svg
                    className="mx-auto h-12 w-12 text-gray-400 mb-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                  <p className="text-lg font-medium">No W2 data yet</p>
                  <p className="text-sm">Upload a W2 form to generate tax documents</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <footer className="mt-16 text-center text-gray-500 text-sm bg-green-100 p-4 rounded-lg">
          <p>Powered by MiniMax AI</p>
          <p className="mt-2">
            This tool is for informational purposes only. Always consult a tax professional.
          </p>
        </footer>
      </div>
    </div>
  );
}
