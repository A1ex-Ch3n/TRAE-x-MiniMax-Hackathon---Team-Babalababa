import { W2Form } from '@/types/w2';
import { Form1040, Form941 } from '@/types/tax-forms';

export class TaxFormMapperService {
  mapW2ToForm1040(w2Forms: W2Form[], taxYear: number, filingStatus: Form1040['filingStatus']): Form1040 {
    const totalWages = this.sumField(w2Forms, 'wagesTipsOtherCompensation');
    const totalFederalTax = this.sumField(w2Forms, 'federalTaxWithheld');
    
    const form1040: Form1040 = {
      taxYear,
      filingStatus,
      taxpayerInfo: {
        ssn: w2Forms[0]?.employee?.ssn || '',
        firstName: w2Forms[0]?.employee?.firstName || '',
        lastName: w2Forms[0]?.employee?.lastName || '',
      },
      address: {
        homeAddress: w2Forms[0]?.employee?.address?.street || '',
        apartmentNumber: '',
        city: w2Forms[0]?.employee?.address?.city || '',
        state: w2Forms[0]?.employee?.address?.state || '',
        zipCode: w2Forms[0]?.employee?.address?.zipCode || '',
      },
      income: {
        wages: totalWages,
        taxableInterest: 0,
        ordinaryDividends: 0,
        iraDistributions: 0,
        pensionsAndAnnuities: 0,
        socialSecurityBenefits: 0,
        capitalGainOrLoss: 0,
        otherIncome: 0,
        totalIncome: totalWages,
      },
      adjustments: {
        educatorExpenses: 0,
        hsaDeduction: 0,
        businessIncomeLoss: 0,
        selfEmploymentTax: 0,
        selfEmploymentHealthInsurance: 0,
        penaltyOnEarlyWithdrawal: 0,
        alaskaPermanentFundDividend: 0,
        otherAdjustments: 0,
        totalAdjustments: 0,
      },
      deductions: {
        standardDeduction: this.getStandardDeduction(filingStatus, taxYear),
        qualifiedBusinessIncomeDeduction: 0,
        sumOfDeductions: this.getStandardDeduction(filingStatus, taxYear),
        taxableIncome: totalWages - this.getStandardDeduction(filingStatus, taxYear),
      },
      taxAndCredits: {
        computedTax: 0,
        alternativeMinimumTax: 0,
        excessAdvancePremiumTaxCreditRepayment: 0,
        totalTax: 0,
        childTaxCredit: 0,
        recoveryRebateCredit: 0,
        otherCredits: 0,
        totalCredits: 0,
      },
      payments: {
        federalTaxWithheld: totalFederalTax,
        estimatedTaxPayments: 0,
        refundableCredits: 0,
        otherPayments: 0,
        totalPayments: totalFederalTax,
      },
      refund: {
        overpayment: totalFederalTax,
        amountRefunded: 0,
        appliedToNextYear: 0,
      },
      amountYouOwe: 0,
      sourceW2s: w2Forms,
    };

    return form1040;
  }

  mapW2ToForm941(w2Forms: W2Form[], taxYear: number, quarter: Form941['quarter']): Form941 {
    const totalSocialSecurityWages = this.sumField(w2Forms, 'socialSecurityWages');
    const totalSocialSecurityTax = this.sumField(w2Forms, 'socialSecurityTaxWithheld');
    const totalMedicareWages = this.sumField(w2Forms, 'medicareWages');
    const totalMedicareTax = this.sumField(w2Forms, 'medicareTaxWithheld');
    const totalFederalWithholding = this.sumField(w2Forms, 'federalTaxWithheld');

    const form941: Form941 = {
      quarter,
      taxYear,
      employerInfo: {
        ein: w2Forms[0]?.employer?.ein || '',
        name: w2Forms[0]?.employer?.name || '',
        address: w2Forms[0]?.employer?.address?.street || '',
        city: w2Forms[0]?.employer?.address?.city || '',
        state: w2Forms[0]?.employer?.address?.state || '',
        zipCode: w2Forms[0]?.employer?.address?.zipCode || '',
      },
      taxLiability: {
        line2: totalFederalWithholding,
        line5a: totalSocialSecurityWages,
        line5b: totalSocialSecurityTax,
        line5c: totalMedicareWages,
        line5d: totalMedicareTax,
        line5e: 0,
        line5f: 0,
        line5_total: totalSocialSecurityTax + totalMedicareTax,
        line6: 0,
        line7: 0,
        line7a: 0,
        line7b: 0,
        line7c: 0,
        line8: 0,
        line10: 0,
        line11: 0,
        line12a: 0,
        line12b: 0,
        line13: 0,
      },
      deposits: {
        totalTaxDeposited: 0,
        overpayment: 0,
        overpaymentApplied: 0,
        overpaymentRefunded: 0,
      },
      monthlyLiability: this.generateMonthlyLiability(w2Forms, taxYear, quarter),
      sourceW2s: w2Forms,
    };

    return form941;
  }

  private sumField(w2Forms: W2Form[], field: string): number {
    return w2Forms.reduce((sum, w2) => {
      const value = this.getNestedValue(w2, field);
      return sum + (typeof value === 'number' ? value : 0);
    }, 0);
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : null;
    }, obj);
  }

  private getStandardDeduction(filingStatus: Form1040['filingStatus'], taxYear: number): number {
    const deductions: Record<number, Record<Form1040['filingStatus'], number>> = {
      2024: {
        single: 14600,
        married_filing_jointly: 29200,
        married_filing_separately: 14600,
        head_of_household: 21900,
        qualifying_surviving_spouse: 29200,
      },
      2023: {
        single: 13850,
        married_filing_jointly: 27700,
        married_filing_separately: 13850,
        head_of_household: 20800,
        qualifying_surviving_spouse: 27700,
      },
      2022: {
        single: 12950,
        married_filing_jointly: 25900,
        married_filing_separately: 12950,
        head_of_household: 19400,
        qualifying_surviving_spouse: 25900,
      },
    };

    return deductions[taxYear]?.[filingStatus] || deductions[2024]?.[filingStatus] || 14600;
  }

  private generateMonthlyLiability(
    w2Forms: W2Form[], 
    taxYear: number, 
    quarter: Form941['quarter']
  ): Form941['monthlyLiability'] {
    const quarterMonths = this.getQuarterMonths(quarter);
    const monthlyWages = this.sumField(w2Forms, 'wagesTipsOtherCompensation') / 3;
    const monthlySSWages = this.sumField(w2Forms, 'socialSecurityWages') / 3;
    const monthlySSWithholding = this.sumField(w2Forms, 'socialSecurityTaxWithheld') / 3;
    const monthlyMedicareWages = this.sumField(w2Forms, 'medicareWages') / 3;
    const monthlyMedicareWithholding = this.sumField(w2Forms, 'medicareTaxWithheld') / 3;
    const monthlyFederalWithholding = this.sumField(w2Forms, 'federalTaxWithheld') / 3;

    return quarterMonths.map(month => ({
      month,
      socialSecurityWages: monthlySSWages,
      socialSecurityTax: monthlySSWithholding,
      medicareWages: monthlyMedicareWages,
      medicareTax: monthlyMedicareWithholding,
      withholdingTax: monthlyFederalWithholding,
    }));
  }

  private getQuarterMonths(quarter: Form941['quarter']): string[] {
    switch (quarter) {
      case 'Q1':
        return ['January', 'February', 'March'];
      case 'Q2':
        return ['April', 'May', 'June'];
      case 'Q3':
        return ['July', 'August', 'September'];
      case 'Q4':
        return ['October', 'November', 'December'];
    }
  }
}

export const taxFormMapperService = new TaxFormMapperService();
