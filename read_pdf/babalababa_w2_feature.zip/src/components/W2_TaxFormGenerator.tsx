'use client';

import { useState } from 'react';
import { W2Form } from '@/types/w2';
import { Form1040, Form941 } from '@/types/tax-forms';

interface TaxFormGeneratorProps {
  w2Forms: W2Form[];
}

export default function W2_TaxFormGenerator({ w2Forms }: TaxFormGeneratorProps) {
  const [selectedForm, setSelectedForm] = useState<'1040' | '941'>('1040');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedForm, setGeneratedForm] = useState<Form1040 | Form941 | null>(null);
  const [error, setError] = useState('');

  // Form 1040 state
  const [filingStatus, setFilingStatus] = useState<Form1040['filingStatus']>('single');
  const [taxYear1040, setTaxYear1040] = useState(new Date().getFullYear() - 1);

  // Form 941 state
  const [quarter, setQuarter] = useState<Form941['quarter']>('Q1');
  const [taxYear941, setTaxYear941] = useState(new Date().getFullYear());

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError('');
    setGeneratedForm(null);

    try {
      const endpoint = selectedForm === '1040' ? '/api/generate-1040' : '/api/generate-941';
      const body = selectedForm === '1040' 
        ? { w2Forms, taxYear: taxYear1040, filingStatus }
        : { w2Forms, taxYear: taxYear941, quarter };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to generate Form ${selectedForm}`);
      }

      const data = await response.json();
      setGeneratedForm(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsGenerating(false);
    }
  };
  
  const formatCurrency = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="card">
      <h2 className="text-2xl font-bold mb-6">Generate Tax Form</h2>

      <div className="mb-6">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setSelectedForm('1040')}
            className={`px-4 py-2 font-medium border-b-2 transition-colors ${
              selectedForm === '1040'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Form 1040
          </button>
          <button
            onClick={() => setSelectedForm('941')}
            className={`px-4 py-2 font-medium border-b-2 transition-colors ${
              selectedForm === '941'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Form 941
          </button>
        </div>
      </div>

      {selectedForm === '1040' && (
        <div className="space-y-4 mb-6">
          <div>
            <label className="form-label">Tax Year</label>
            <select 
              value={taxYear1040} 
              onChange={(e) => setTaxYear1040(Number(e.target.value))}
              className="form-input"
            >
              <option>{new Date().getFullYear() - 1}</option>
              <option>{new Date().getFullYear() - 2}</option>
              <option>{new Date().getFullYear() - 3}</option>
            </select>
          </div>
          <div>
            <label className="form-label">Filing Status</label>
            <select 
              value={filingStatus} 
              onChange={(e) => setFilingStatus(e.target.value as Form1040['filingStatus'])}
              className="form-input"
            >
              <option value="single">Single</option>
              <option value="married_filing_jointly">Married filing jointly</option>
              <option value="married_filing_separately">Married filing separately</option>
              <option value="head_of_household">Head of household</option>
              <option value="qualifying_surviving_spouse">Qualifying surviving spouse</option>
            </select>
          </div>
        </div>
      )}

      {selectedForm === '941' && (
        <div className="space-y-4 mb-6">
          <div>
            <label className="form-label">Tax Year</label>
            <select 
              value={taxYear941} 
              onChange={(e) => setTaxYear941(Number(e.target.value))}
              className="form-input"
            >
              <option>{new Date().getFullYear()}</option>
              <option>{new Date().getFullYear() - 1}</option>
            </select>
          </div>
          <div>
            <label className="form-label">Quarter</label>
            <select 
              value={quarter} 
              onChange={(e) => setQuarter(e.target.value as Form941['quarter'])}
              className="form-input"
            >
              <option value="Q1">Q1 (Jan-Mar)</option>
              <option value="Q2">Q2 (Apr-Jun)</option>
              <option value="Q3">Q3 (Jul-Sep)</option>
              <option value="Q4">Q4 (Oct-Dec)</option>
            </select>
          </div>
        </div>
      )}

      <button onClick={handleGenerate} disabled={isGenerating} className="btn-primary w-full">
        {isGenerating ? 'Generating...' : `Generate Form ${selectedForm}`}
      </button>

      {error && (
        <div className="mt-4 text-red-600 bg-red-50 p-3 rounded-lg">{error}</div>
      )}

      {generatedForm && (
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">Generated Form {selectedForm}</h3>
          <div className="bg-gray-50 rounded-lg p-4 overflow-auto max-h-[500px]">
            <pre className="text-sm font-mono whitespace-pre-wrap">
              {JSON.stringify(generatedForm, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
